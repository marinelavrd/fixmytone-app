from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from openai import OpenAI
import os

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

app = FastAPI(
    title="FixMyTone",
    version="0.3.0",
    description="Rewrite any text to a different tone via POST /rewrite or generate replies via POST /respond",
)

class RewriteRequest(BaseModel):
    text: str
    tone: str

class RespondRequest(BaseModel):
    received_message: str
    user_intent: str
    tone: str

class RewriteResponse(BaseModel):
    rewritten_text: str

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    with open("index.html", "r") as f:
        return f.read()

@app.post("/rewrite", response_model=RewriteResponse)
async def rewrite(req: RewriteRequest):
    # Few-shot prompt for "Fix my tone"
    messages = [
        {
            "role": "system",
            "content": (
                "You are a writing assistant that rewrites messages to sound more "
                f"{req.tone}. Preserve the original meaning, keep the message short "
                "and copy-paste ready. Don’t add disclaimers, explanations, or break character. "
                "Output only the rewritten message."
            ),
        },
        {
            "role": "user",
            "content": "Original: Can we meet later today?\nTone: Slightly Petty"
        },
        {
            "role": "assistant",
            "content": "Sure, if you’re finally free now."
        },
        {
            "role": "user",
            "content": f"Original: {req.text}\nTone: {req.tone}"
        },
    ]

    try:
        resp = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=0.7,
            max_tokens=250,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    rewritten = resp.choices[0].message.content.strip()
    return {"rewritten_text": rewritten}


@app.post("/respond", response_model=RewriteResponse)
async def respond(req: RespondRequest):
    # Few-shot prompt for "Tell me what to say"
    messages = [
        {
            "role": "system",
            "content": (
                "You craft clever, emotionally intelligent replies to text messages. "
                "You always reflect the user's true intent and chosen tone. Keep responses "
                "short and copy-paste ready — no explanations or extra commentary. "
                "Never mention you're an AI. Just write the response."
            ),
        },
        {
            "role": "user",
            "content": (
                "Message received: 'u up?'\n"
                "User wants to say: 'yeah but I don't want to talk to you'\n"
                "Tone: Friendly but Clear"
            ),
        },
        {
            "role": "assistant",
            "content": "I am, but not in the mood to talk right now. Hope you’re good."
        },
        {
            "role": "user",
            "content": (
                "Message received: 'hey, why didn’t you text me back?'\n"
                "User wants to say: 'because I didn’t feel like it'\n"
                "Tone: Polite Professional"
            ),
        },
        {
            "role": "assistant",
            "content": "I needed some space, thanks for understanding."
        },
        {
            "role": "user",
            "content": (
                f"Message received: '{req.received_message}'\n"
                f"User wants to say: '{req.user_intent}'\n"
                f"Tone: {req.tone}"
            ),
        },
    ]

    try:
        resp = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=0.8,
            max_tokens=250,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    rewritten = resp.choices[0].message.content.strip()
    return {"rewritten_text": rewritten}